// Duration strings like "1d 2h 30m 10s" <-> seconds.
const UNITS: Record<string, number> = { d: 86400, h: 3600, m: 60, s: 1 };

export function parseDuration(input: string): number | null {
  const text = input.trim().toLowerCase().replace(/\s+/g, "");
  if (!text) return null;
  const re = /(\d+)([dhms])/g;
  let total = 0;
  let consumed = 0;
  let match: RegExpExecArray | null;
  while ((match = re.exec(text)) !== null) {
    total += Number(match[1]) * (UNITS[match[2] ?? "s"] ?? 0);
    consumed += match[0].length;
  }
  if (consumed !== text.length || total <= 0) return null;
  return total;
}

export function formatDuration(totalSeconds: number): string {
  let s = Math.max(0, Math.floor(totalSeconds));
  const d = Math.floor(s / 86400);
  s -= d * 86400;
  const h = Math.floor(s / 3600);
  s -= h * 3600;
  const m = Math.floor(s / 60);
  s -= m * 60;
  const parts: string[] = [];
  if (d) parts.push(`${d}d`);
  if (h) parts.push(`${h}h`);
  if (m) parts.push(`${m}m`);
  if (s || parts.length === 0) parts.push(`${s}s`);
  return parts.join(" ");
}
