import { z } from "zod";
import { evaluateActivation } from "./license-rules";

// Shared handler for the iPhone app's key check. Accepts several field-name spellings.
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

const str = (max: number) => z.string().trim().min(1).max(max).optional();
const schema = z.object({
  key: z.string().trim().min(8).max(64).regex(/^[A-Za-z0-9-]+$/, "invalid_key_format"),
  device_id: z.string().trim().min(1).max(128),
  device_model: str(80),
  device_name: str(120),
  ios_version: str(40),
});

function pick(src: Record<string, unknown>, names: string[]): string | undefined {
  for (const n of names) {
    const v = src[n];
    if (typeof v === "string" && v.trim()) return v;
    if (typeof v === "number") return String(v);
  }
  return undefined;
}

function json(body: unknown, status = 200) {
  return Response.json(body, { status, headers: CORS });
}

export function corsPreflight() {
  return new Response(null, { status: 204, headers: CORS });
}

export async function handleLicenseRequest(request: Request): Promise<Response> {
  let raw: Record<string, unknown> = {};
  if (request.method === "GET") {
    raw = Object.fromEntries(new URL(request.url).searchParams);
  } else {
    try {
      const text = await request.text();
      raw = text ? (JSON.parse(text) as Record<string, unknown>) : {};
    } catch {
      return json({ ok: false, error: "invalid_request", message: "JSON no válido." }, 400);
    }
    const nested = raw?.["device"];
    if (nested && typeof nested === "object") raw = { ...(nested as Record<string, unknown>), ...raw };
  }

  const parsed = schema.safeParse({
    key: pick(raw, ["key", "license", "license_key", "licenseKey", "code"]) ?? "",
    device_id: pick(raw, ["device_id", "deviceId", "deviceID", "hwid", "udid", "identifier", "idfv", "vendor_id"]) ?? "",
    device_model: pick(raw, ["device_model", "deviceModel", "model", "machine", "hardware", "model_identifier"]),
    device_name: pick(raw, ["device_name", "deviceName", "name", "phone_name"]),
    ios_version: pick(raw, ["ios_version", "iosVersion", "system_version", "systemVersion", "os_version", "osVersion"]),
  });
  if (!parsed.success) {
    return json(
      {
        ok: false,
        error: "invalid_request",
        message: "La key o el identificador del dispositivo no es válido.",
      },
      400,
    );
  }
  const input = parsed.data;
  const keyValue = input.key.toUpperCase();

  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: row, error } = await supabaseAdmin
    .from("license_keys")
    .select("*")
    .eq("key", keyValue)
    .maybeSingle();
  if (error) return json({ ok: false, error: "server_error", message: "Error del servidor." }, 500);
  if (!row) return json({ ok: false, error: "not_found", status: "not_found", message: "La key no existe." }, 404);

  const now = new Date();
  const result = evaluateActivation(row, input.device_id, now);
  if (!result.ok) {
    return json({ ok: false, error: result.error, status: result.error, message: result.message }, 403);
  }

  await supabaseAdmin
    .from("license_keys")
    .update({
      device_id: input.device_id,
      device_model: input.device_model ?? row.device_model,
      device_name: input.device_name ?? row.device_name,
      ios_version: input.ios_version ?? row.ios_version,
      activated_at: result.activatedAt,
      expires_at: result.expiresAt,
      last_seen_at: now.toISOString(),
    })
    .eq("id", row.id);

  const expiresMs = result.expiresAt ? new Date(result.expiresAt).getTime() : null;
  return json({
    ok: true,
    success: true,
    valid: true,
    status: "active",
    message: result.firstActivation ? "Key activada." : "Key válida.",
    key: keyValue,
    role: "user",
    menus: [],
    permanent: row.permanent,
    expires_at: result.expiresAt,
    expires_at_ms: expiresMs,
    remaining_seconds: expiresMs ? Math.floor((expiresMs - now.getTime()) / 1000) : null,
  });
}
