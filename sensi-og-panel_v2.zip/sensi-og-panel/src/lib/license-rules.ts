// Pure rules for key activation and time extension (shared by the API and the panel).
export type KeyRow = {
  key: string;
  duration_seconds: number;
  permanent: boolean;
  revoked: boolean;
  activated_at: string | null;
  expires_at: string | null;
  device_id: string | null;
};

export type ActivationResult =
  | { ok: true; firstActivation: boolean; activatedAt: string; expiresAt: string | null }
  | { ok: false; error: "revoked" | "bound_other_device" | "expired"; message: string };

export function evaluateActivation(row: KeyRow, deviceId: string, now: Date): ActivationResult {
  if (row.revoked) return { ok: false, error: "revoked", message: "Esta key fue revocada." };
  if (row.device_id && row.device_id !== deviceId) {
    return { ok: false, error: "bound_other_device", message: "Esta key está vinculada a otro dispositivo." };
  }
  const firstActivation = !row.device_id;
  const activatedAt = row.activated_at ?? now.toISOString();
  let expiresAt = row.permanent ? null : row.expires_at;
  if (!row.permanent && !expiresAt) {
    expiresAt = new Date(now.getTime() + row.duration_seconds * 1000).toISOString();
  }
  if (expiresAt && new Date(expiresAt).getTime() <= now.getTime()) {
    return { ok: false, error: "expired", message: "La key ha vencido." };
  }
  return { ok: true, firstActivation, activatedAt, expiresAt };
}

/** Adds time to a key. Expired keys restart counting from now. */
export function extendKey(
  row: Pick<KeyRow, "duration_seconds" | "expires_at">,
  addSeconds: number,
  now: Date,
): { duration_seconds: number; expires_at: string | null } {
  const duration_seconds = row.duration_seconds + addSeconds;
  if (!row.expires_at) return { duration_seconds, expires_at: null };
  const base = Math.max(new Date(row.expires_at).getTime(), now.getTime());
  return { duration_seconds, expires_at: new Date(base + addSeconds * 1000).toISOString() };
}

const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
export function generateKeyString(): string {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  const chars = Array.from(bytes, (b) => ALPHABET[b % ALPHABET.length]).join("");
  return chars.match(/.{4}/g)!.join("-");
}
