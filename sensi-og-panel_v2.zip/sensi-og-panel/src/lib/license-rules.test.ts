import { describe, expect, it } from "vitest";
import { evaluateActivation, extendKey, generateKeyString } from "./license-rules";
import { formatDuration, parseDuration } from "./duration";

const now = new Date("2026-01-01T00:00:00.000Z");
const base = {
  key: "AAAA-BBBB-CCCC-DDDD",
  duration_seconds: 86400,
  permanent: false,
  revoked: false,
  activated_at: null,
  expires_at: null,
  device_id: null,
};

describe("durations", () => {
  it("parses 1d 1h 1m 1s", () => expect(parseDuration("1d 1h 1m 1s")).toBe(90061));
  it("parses a single unit", () => expect(parseDuration("30m")).toBe(1800));
  it("rejects invalid text", () => expect(parseDuration("10x")).toBeNull());
  it("formats seconds back", () => expect(formatDuration(90061)).toBe("1d 1h 1m 1s"));
});

describe("activation", () => {
  it("starts the timer on first activation", () => {
    const r = evaluateActivation(base, "dev-1", now);
    expect(r).toMatchObject({ ok: true, firstActivation: true, expiresAt: "2026-01-02T00:00:00.000Z" });
  });
  it("blocks a second device", () => {
    const r = evaluateActivation({ ...base, device_id: "dev-1" }, "dev-2", now);
    expect(r).toMatchObject({ ok: false, error: "bound_other_device" });
  });
  it("rejects expired keys", () => {
    const r = evaluateActivation({ ...base, device_id: "dev-1", expires_at: "2025-12-31T23:59:59.000Z" }, "dev-1", now);
    expect(r).toMatchObject({ ok: false, error: "expired" });
  });
  it("rejects revoked keys", () => {
    expect(evaluateActivation({ ...base, revoked: true }, "dev-1", now)).toMatchObject({ ok: false, error: "revoked" });
  });
  it("permanent keys never expire", () => {
    expect(evaluateActivation({ ...base, permanent: true }, "dev-1", now)).toMatchObject({ ok: true, expiresAt: null });
  });
});

describe("extend", () => {
  it("adds time to an active key", () => {
    const r = extendKey({ duration_seconds: 3600, expires_at: "2026-01-01T01:00:00.000Z" }, 3600, now);
    expect(r.expires_at).toBe("2026-01-01T02:00:00.000Z");
  });
  it("restarts from now for an expired key", () => {
    const r = extendKey({ duration_seconds: 3600, expires_at: "2025-12-31T00:00:00.000Z" }, 60, now);
    expect(r.expires_at).toBe("2026-01-01T00:01:00.000Z");
  });
  it("adds to the pending duration of an unused key", () => {
    expect(extendKey({ duration_seconds: 3600, expires_at: null }, 60, now)).toEqual({ duration_seconds: 3660, expires_at: null });
  });
});

it("generates keys in XXXX-XXXX-XXXX-XXXX format", () => {
  expect(generateKeyString()).toMatch(/^[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}$/);
});
