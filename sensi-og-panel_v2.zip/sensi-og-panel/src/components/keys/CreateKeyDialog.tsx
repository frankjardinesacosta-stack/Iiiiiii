import { useState } from "react";
import { Loader2, Plus } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { parseDuration } from "@/lib/duration";
import { generateKeyString } from "@/lib/license-rules";
import { DurationField } from "./DurationField";

export function CreateKeyDialog({ onCreated }: { onCreated: (keys: string[]) => void }) {
  const [open, setOpen] = useState(false);
  const [duration, setDuration] = useState("1d");
  const [permanent, setPermanent] = useState(false);
  const [quantity, setQuantity] = useState(1);
  const [note, setNote] = useState("");
  const [startOn, setStartOn] = useState<"activation" | "now">("now");
  const [busy, setBusy] = useState(false);

  const seconds = parseDuration(duration);
  const valid = permanent || !!seconds;

  async function create() {
    if (!valid) return;
    setBusy(true);
    const now = Date.now();
    const rows = Array.from({ length: Math.min(Math.max(quantity, 1), 50) }, () => ({
      key: generateKeyString(),
      duration_seconds: permanent ? 0 : seconds!,
      permanent,
      note: note.trim() || null,
      expires_at: !permanent && startOn === "now" ? new Date(now + seconds! * 1000).toISOString() : null,
    }));
    const { error } = await supabase.from("license_keys").insert(rows);
    setBusy(false);
    if (error) {
      toast.error("No se pudieron crear las keys");
      return;
    }
    const keys = rows.map((r) => r.key);
    await navigator.clipboard?.writeText(keys.join("\n")).catch(() => {});
    toast.success(keys.length === 1 ? "Key creada y copiada" : `${keys.length} keys creadas y copiadas`);
    onCreated(keys);
    setOpen(false);
    setNote("");
    setQuantity(1);
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="hero" size="lg" className="w-full sm:w-auto">
          <Plus /> Generar key
        </Button>
      </DialogTrigger>
      <DialogContent className="max-h-[90dvh] w-[calc(100%-1.5rem)] overflow-y-auto rounded-2xl">
        <DialogHeader>
          <DialogTitle className="font-display">Nueva key</DialogTitle>
        </DialogHeader>
        <div className="space-y-5">
          <div className="flex items-center justify-between rounded-lg border border-border p-3">
            <div>
              <Label htmlFor="permanent">Permanente</Label>
              <p className="text-xs text-muted-foreground">Nunca vence</p>
            </div>
            <Switch id="permanent" checked={permanent} onCheckedChange={setPermanent} />
          </div>

          {!permanent && (
            <>
              <div className="space-y-2">
                <Label htmlFor="duration">Duración</Label>
                <DurationField id="duration" value={duration} onChange={setDuration} />
              </div>
              <div className="space-y-2">
                <Label>El tiempo empieza</Label>
                <ToggleGroup
                  type="single"
                  value={startOn}
                  onValueChange={(v) => v && setStartOn(v as "activation" | "now")}
                  className="grid grid-cols-2"
                  variant="outline"
                >
                  <ToggleGroupItem value="now">Desde ahora</ToggleGroupItem>
                  <ToggleGroupItem value="activation">Al activarla</ToggleGroupItem>
                </ToggleGroup>
              </div>
            </>
          )}

          <div className="grid grid-cols-[96px_1fr] gap-3">
            <div className="space-y-2">
              <Label htmlFor="qty">Cantidad</Label>
              <Input
                id="qty"
                type="number"
                min={1}
                max={50}
                value={quantity}
                onChange={(e) => setQuantity(Number(e.target.value) || 1)}
                className="h-11 font-mono"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="note">Nota (opcional)</Label>
              <Input
                id="note"
                value={note}
                maxLength={80}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Cliente, precio…"
                className="h-11"
              />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="hero" size="lg" className="w-full" disabled={!valid || busy} onClick={create}>
            {busy && <Loader2 className="animate-spin" />}
            Crear {quantity > 1 ? `${Math.min(quantity, 50)} keys` : "key"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
