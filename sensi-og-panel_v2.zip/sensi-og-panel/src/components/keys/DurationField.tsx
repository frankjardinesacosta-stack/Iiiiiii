import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { formatDuration, parseDuration } from "@/lib/duration";

const PRESETS = ["1h", "1d", "3d", "7d", "15d", "30d"];

export function DurationField({
  value,
  onChange,
  id,
}: {
  value: string;
  onChange: (v: string) => void;
  id: string;
}) {
  const seconds = parseDuration(value);
  return (
    <div className="space-y-2">
      <Input
        id={id}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Ej: 1d 2h 30m 10s"
        className="h-11 font-mono"
        autoComplete="off"
      />
      <div className="flex flex-wrap gap-1.5">
        {PRESETS.map((p) => (
          <Button key={p} type="button" size="sm" variant="chip" onClick={() => onChange(p)}>
            {p}
          </Button>
        ))}
      </div>
      <p className={seconds ? "text-xs text-muted-foreground" : "text-xs text-destructive"}>
        {value.trim() === ""
          ? "Usa d = días, h = horas, m = minutos, s = segundos."
          : seconds
            ? `= ${formatDuration(seconds)}`
            : "Formato no válido. Ejemplo: 1d 1h 1m 1s"}
      </p>
    </div>
  );
}
