import { useState } from "react";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { formatDuration, parseDuration } from "@/lib/duration";
import { extendKey } from "@/lib/license-rules";
import { DurationField } from "./DurationField";
import type { LicenseKey } from "./types";

export function ExtendDialog({
  item,
  onOpenChange,
  onDone,
}: {
  item: LicenseKey | null;
  onOpenChange: (open: boolean) => void;
  onDone: () => void;
}) {
  const [value, setValue] = useState("1d");
  const [busy, setBusy] = useState(false);
  const seconds = parseDuration(value);

  async function save() {
    if (!item || !seconds) return;
    setBusy(true);
    const patch = extendKey(item, seconds, new Date());
    const { error } = await supabase.from("license_keys").update(patch).eq("id", item.id);
    setBusy(false);
    if (error) {
      toast.error("No se pudo aumentar el tiempo");
      return;
    }
    toast.success(`+${formatDuration(seconds)} agregado`);
    onDone();
    onOpenChange(false);
  }

  return (
    <Dialog open={!!item} onOpenChange={onOpenChange}>
      <DialogContent className="w-[calc(100%-1.5rem)] rounded-2xl">
        <DialogHeader>
          <DialogTitle className="font-display">Aumentar tiempo</DialogTitle>
        </DialogHeader>
        <p className="font-mono text-sm text-primary">{item?.key}</p>
        <div className="space-y-2">
          <Label htmlFor="extend">Tiempo a sumar</Label>
          <DurationField id="extend" value={value} onChange={setValue} />
        </div>
        <DialogFooter>
          <Button variant="hero" size="lg" className="w-full" disabled={!seconds || busy} onClick={save}>
            {busy && <Loader2 className="animate-spin" />}
            Sumar tiempo
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
