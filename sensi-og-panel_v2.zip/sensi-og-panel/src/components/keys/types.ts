import type { Database } from "@/integrations/supabase/types";
export type LicenseKey = Database["public"]["Tables"]["license_keys"]["Row"];

export type KeyStatus = "unused" | "active" | "expired" | "revoked";

export function keyStatus(k: LicenseKey, now: number): KeyStatus {
  if (k.revoked) return "revoked";
  if (k.expires_at && new Date(k.expires_at).getTime() <= now) return "expired";
  if (!k.device_id) return "unused";
  return "active";
}
