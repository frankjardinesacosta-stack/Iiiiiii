import { Clock, Copy, MoreVertical, Smartphone, Trash2, Unlink, Ban, RotateCcw, TimerReset } from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { formatDuration } from "@/lib/duration";
import { friendlyModel } from "@/lib/device-names";
import { cn } from "@/lib/utils";
import { keyStatus, type KeyStatus, type LicenseKey } from "./types";

const STATUS: Record<KeyStatus, { label: string; className: string }> = {
  active: { label: "Activa", className: "border-success/40 bg-success/15 text-success" },
  unused: { label: "Sin usar", className: "border-primary/40 bg-primary/10 text-primary" },
  expired: { label: "Vencida", className: "border-warning/40 bg-warning/15 text-warning" },
  revoked: { label: "Revocada", className: "border-destructive/40 bg-destructive/15 text-destructive" },
};

function timeLabel(k: LicenseKey, now: number) {
  if (k.permanent) return "Permanente";
  if (!k.expires_at) return `${formatDuration(k.duration_seconds)} · empieza al activar`;
  const left = Math.floor((new Date(k.expires_at).getTime() - now) / 1000);
  if (left <= 0) return "Sin tiempo";
  return `Quedan ${formatDuration(left)}`;
}

export function KeyCard({
  item,
  now,
  onExtend,
  onReset,
  onToggleRevoke,
  onDelete,
}: {
  item: LicenseKey;
  now: number;
  onExtend: () => void;
  onReset: () => void;
  onToggleRevoke: () => void;
  onDelete: () => void;
}) {
  const status = keyStatus(item, now);
  const s = STATUS[status];
  const model = friendlyModel(item.device_model);

  return (
    <article className="rounded-2xl border border-border bg-card p-4 transition-colors hover:border-primary/40">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <button
            type="button"
            onClick={() => {
              navigator.clipboard?.writeText(item.key);
              toast.success("Key copiada");
            }}
            className="group flex items-center gap-2 text-left font-mono text-[15px] font-bold tracking-wide text-foreground"
          >
            <span className="truncate">{item.key}</span>
            <Copy className="size-3.5 shrink-0 text-muted-foreground group-hover:text-primary" />
          </button>
          {item.note && <p className="mt-0.5 truncate text-xs text-muted-foreground">{item.note}</p>}
        </div>
        <div className="flex shrink-0 items-center gap-1">
          <Badge variant="outline" className={cn("gap-1.5 font-mono text-[11px]", s.className)}>
            {status === "active" && <span className="size-1.5 animate-pulse-dot rounded-full bg-current" />}
            {s.label}
          </Badge>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" aria-label="Opciones de la key">
                <MoreVertical />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {!item.permanent && (
                <DropdownMenuItem onClick={onExtend}>
                  <TimerReset /> Aumentar tiempo
                </DropdownMenuItem>
              )}
              {item.device_id && (
                <DropdownMenuItem onClick={onReset}>
                  <Unlink /> Liberar dispositivo
                </DropdownMenuItem>
              )}
              <DropdownMenuItem onClick={onToggleRevoke}>
                {item.revoked ? <RotateCcw /> : <Ban />} {item.revoked ? "Reactivar" : "Revocar"}
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={onDelete} className="text-destructive focus:text-destructive">
                <Trash2 /> Eliminar
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      <div className="mt-3 flex items-center gap-2 font-mono text-xs text-muted-foreground">
        <Clock className="size-3.5" />
        <span className={status === "active" ? "text-foreground" : undefined}>{timeLabel(item, now)}</span>
      </div>

      <div className="mt-3 rounded-xl border border-dashed border-border bg-background/40 p-3">
        {item.device_id ? (
          <div className="flex gap-3">
            <div className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-secondary text-primary">
              <Smartphone className="size-4" />
            </div>
            <dl className="grid min-w-0 flex-1 grid-cols-[auto_1fr] gap-x-3 gap-y-0.5 text-xs">
              <dt className="text-muted-foreground">Nombre</dt>
              <dd className="truncate font-medium text-foreground">{item.device_name ?? "—"}</dd>
              <dt className="text-muted-foreground">Modelo</dt>
              <dd className="truncate text-foreground">
                {model ?? "—"}
                {model && model !== item.device_model && (
                  <span className="ml-1 font-mono text-muted-foreground">({item.device_model})</span>
                )}
              </dd>
              <dt className="text-muted-foreground">iOS</dt>
              <dd className="font-mono text-foreground">{item.ios_version ?? "—"}</dd>
              <dt className="text-muted-foreground">ID</dt>
              <dd className="truncate font-mono text-muted-foreground">{item.device_id}</dd>
            </dl>
          </div>
        ) : (
          <p className="text-xs text-muted-foreground">Ningún dispositivo registrado todavía.</p>
        )}
      </div>
    </article>
  );
}
