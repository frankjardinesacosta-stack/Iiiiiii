import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { KeyRound, Loader2, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Entrar · SENSI OG Panel de keys" },
      { name: "description", content: "Accede a tu panel privado para crear y controlar keys con tiempo." },
      { property: "og:title", content: "Entrar · SENSI OG Panel de keys" },
      { property: "og:description", content: "Accede a tu panel privado para crear y controlar keys con tiempo." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

type Mode = "loading" | "login" | "create" | "check-email";

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<Mode>("loading");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let active = true;
    (async () => {
      const { data: userData } = await supabase.auth.getUser();
      if (userData.user) {
        navigate({ to: "/panel" });
        return;
      }
      const { data } = await supabase.rpc("owner_exists");
      if (active) setMode(data ? "login" : "create");
    })();
    return () => {
      active = false;
    };
  }, [navigate]);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "create") {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: window.location.origin },
        });
        if (error) throw error;
        if (data.session) navigate({ to: "/panel" });
        else setMode("check-email");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        navigate({ to: "/panel" });
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Algo salió mal";
      toast.error(
        mode === "create" && /database error/i.test(msg)
          ? "Ya existe la cuenta principal. Solo puedes iniciar sesión."
          : msg === "Invalid login credentials"
            ? "Correo o contraseña incorrectos."
            : msg,
      );
      if (mode === "create" && /database error/i.test(msg)) setMode("login");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="grid-noise flex min-h-dvh items-center justify-center px-5 py-10">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex flex-col items-center text-center">
          <div className="mb-5 flex size-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-glow">
            <KeyRound className="size-7" />
          </div>
          <h1 className="text-2xl font-extrabold">SENSI OG</h1>
          <p className="mt-1 font-mono text-xs uppercase tracking-[0.25em] text-muted-foreground">
            Panel de keys
          </p>
        </div>

        <div className="rounded-2xl border border-border bg-card/80 p-6 backdrop-blur">
          {mode === "loading" && (
            <div className="flex justify-center py-10 text-muted-foreground">
              <Loader2 className="size-6 animate-spin" />
            </div>
          )}

          {mode === "check-email" && (
            <div className="space-y-3 py-4 text-center">
              <ShieldCheck className="mx-auto size-10 text-primary" />
              <h2 className="text-lg font-semibold">Revisa tu correo</h2>
              <p className="text-sm text-muted-foreground">
                Te enviamos un enlace a <span className="text-foreground">{email}</span>. Ábrelo para confirmar tu
                cuenta principal y luego inicia sesión aquí.
              </p>
              <Button variant="outline" className="w-full" onClick={() => setMode("login")}>
                Ir a iniciar sesión
              </Button>
            </div>
          )}

          {(mode === "login" || mode === "create") && (
            <form onSubmit={onSubmit} className="space-y-4">
              <div>
                <h2 className="text-lg font-semibold">
                  {mode === "create" ? "Crear cuenta principal" : "Iniciar sesión"}
                </h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  {mode === "create"
                    ? "Esta será la única cuenta del panel. Después nadie más podrá registrarse."
                    : "Solo la cuenta principal puede entrar."}
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Correo</Label>
                <Input
                  id="email"
                  type="email"
                  autoComplete="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="h-11"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Contraseña</Label>
                <Input
                  id="password"
                  type="password"
                  autoComplete={mode === "create" ? "new-password" : "current-password"}
                  minLength={6}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-11"
                />
              </div>
              <Button type="submit" variant="hero" size="lg" className="w-full" disabled={busy}>
                {busy && <Loader2 className="animate-spin" />}
                {mode === "create" ? "Crear cuenta" : "Entrar"}
              </Button>
            </form>
          )}
        </div>
      </div>
    </main>
  );
}
