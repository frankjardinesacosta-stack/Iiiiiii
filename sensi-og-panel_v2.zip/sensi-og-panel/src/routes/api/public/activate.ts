import { createFileRoute } from "@tanstack/react-router";
import { corsPreflight, handleLicenseRequest } from "@/lib/license-api";

export const Route = createFileRoute("/api/public/activate")({
  server: {
    handlers: {
      OPTIONS: async () => corsPreflight(),
      GET: async ({ request }) => handleLicenseRequest(request),
      POST: async ({ request }) => handleLicenseRequest(request),
    },
  },
});
