import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { queryOptions, useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { Copy, KeyRound, LogOut, Search } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { CreateKeyDialog } from "@/components/keys/CreateKeyDialog";
import { ExtendDialog } from "@/components/keys/ExtendDialog";
import { KeyCard } from "@/components/keys/KeyCard";
import { keyStatus, type KeyStatus, type LicenseKey } from "@/components/keys/types";

const keysQuery = queryOptions({
  queryKey: ["license_keys"],
  queryFn: async () => {
    const { data, error } = await supabase
      .from("license_keys")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw error;
    return data;
  },
  refetchInterval: 15000,
});

export const Route = createFileRoute("/_authenticated/panel")({
  head: () => ({
    meta: [
      { title: "Mis keys · SENSI OG Panel" },
      { name: "description", content: "Crea, elimina y aumenta el tiempo de tus keys y mira qué iPhone usa cada una." },
      { property: "og:title", content: "Mis keys · SENSI OG Panel" },
      { property: "og:description", content: "Crea, elimina y aumenta el tiempo de tus keys y mira qué iPhone usa cada una." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(keysQuery),
  component: Panel,
});

type Filter = "all" | KeyStatus;

function Panel() {
  const { data: keys } = useSuspenseQuery(keysQuery);
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [now, setNow] = useState(() => Date.now());
  const [filter, setFilter] = useState<Filter>("all");
  const [search, setSearch] = useState("");
  const [extending, setExtending] = useState<LicenseKey | null>(null);
  const [deleting, setDeleting] = useState<LicenseKey | null>(null);
  const [apiUrl, setApiUrl] = useState("");

  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    setApiUrl(`${window.location.origin}/api/public/activate`);
    return () => clearInterval(t);
  }, []);

  const refresh = () => qc.invalidateQueries({ queryKey: keysQuery.queryKey });

  const counts = useMemo(() => {
    const c = { all: keys.length, active: 0, unused: 0, expired: 0, revoked: 0 };
    for (const k of keys) c[keyStatus(k, now)]++;
    return c;
  }, [keys, now]);

  const visible = keys.filter((k) => {
    if (filter !== "all" && keyStatus(k, now) !== filter) return false;
    const q = search.trim().toLowerCase();
    if (!q) return true;
    return [k.key, k.note, k.device_name, k.device_model].some((v) => v?.toLowerCase().includes(q));
  });

  async function update(id: string, patch: Partial<LicenseKey>, ok: string) {
    const { error } = await supabase.from("license_keys").update(patch).eq("id", id);
    if (error) {
      toast.error("No se pudo guardar el cambio");
      return;
    }
    toast.success(ok);
    refresh();
  }

  async function remove() {
    if (!deleting) return;
    const { error } = await supabase.from("license_keys").delete().eq("id", deleting.id);
    setDeleting(null);
    if (error) {
      toast.error("No se pudo eliminar");
      return;
    }
    toast.success("Key eliminada");
    refresh();
  }

  async function signOut() {
    await supabase.auth.signOut();
    navigate({ to: "/" });
  }

  return (
    <div className="mx-auto min-h-dvh max-w-6xl px-4 pb-16 pt-5 sm:px-6 lg:px-8">
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex size-10 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-glow">
            <KeyRound className="size-5" />
          </div>
          <div>
            <h1 className="text-lg font-extrabold leading-none">SENSI OG</h1>
            <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Panel de keys</p>
          </div>
        </div>
        <Button variant="ghost" size="sm" onClick={signOut}>
          <LogOut /> Salir
        </Button>
      </header>

      <section className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat label="Total" value={counts.all} />
        <Stat label="Activas" value={counts.active} accent="text-success" />
        <Stat label="Sin usar" value={counts.unused} accent="text-primary" />
        <Stat label="Vencidas" value={counts.expired} accent="text-warning" />
      </section>

      <section className="mt-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <CreateKeyDialog onCreated={refresh} />
        <div className="relative sm:w-72">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar key, nota o teléfono"
            className="h-11 pl-9"
          />
        </div>
      </section>

      <Tabs value={filter} onValueChange={(v) => setFilter(v as Filter)} className="mt-4">
        <TabsList className="h-auto w-full flex-wrap justify-start gap-1 sm:w-auto">
          <TabsTrigger value="all">Todas</TabsTrigger>
          <TabsTrigger value="active">Activas</TabsTrigger>
          <TabsTrigger value="unused">Sin usar</TabsTrigger>
          <TabsTrigger value="expired">Vencidas</TabsTrigger>
          <TabsTrigger value="revoked">Revocadas</TabsTrigger>
        </TabsList>
      </Tabs>

      <section className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {visible.map((k) => (
          <KeyCard
            key={k.id}
            item={k}
            now={now}
            onExtend={() => setExtending(k)}
            onReset={() =>
              update(
                k.id,
                { device_id: null, device_name: null, device_model: null, ios_version: null },
                "Dispositivo liberado",
              )
            }
            onToggleRevoke={() => update(k.id, { revoked: !k.revoked }, k.revoked ? "Key reactivada" : "Key revocada")}
            onDelete={() => setDeleting(k)}
          />
        ))}
        {visible.length === 0 && (
          <div className="col-span-full rounded-2xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">
            {keys.length === 0 ? "Aún no tienes keys. Genera la primera." : "No hay keys con este filtro."}
          </div>
        )}
      </section>

      <section className="mt-8 rounded-2xl border border-border bg-card/60 p-4">
        <h2 className="text-sm font-semibold">Dirección para tu app</h2>
        <p className="mt-1 text-xs text-muted-foreground">
          Tu app de iPhone debe enviar la key y los datos del teléfono a esta dirección.
        </p>
        <button
          type="button"
          onClick={() => {
            navigator.clipboard?.writeText(apiUrl);
            toast.success("Dirección copiada");
          }}
          className="mt-3 flex w-full items-center justify-between gap-2 rounded-lg bg-background/60 px-3 py-2 text-left font-mono text-xs text-primary"
        >
          <span className="truncate">{apiUrl}</span>
          <Copy className="size-3.5 shrink-0" />
        </button>
      </section>

      <ExtendDialog item={extending} onOpenChange={(o) => !o && setExtending(null)} onDone={refresh} />

      <AlertDialog open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)}>
        <AlertDialogContent className="w-[calc(100%-1.5rem)] rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>¿Eliminar esta key?</AlertDialogTitle>
            <AlertDialogDescription>
              <span className="font-mono text-foreground">{deleting?.key}</span> dejará de funcionar en el teléfono
              donde esté activada. No se puede deshacer.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={remove} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function Stat({ label, value, accent }: { label: string; value: number; accent?: string }) {
  return (
    <div className="rounded-2xl border border-border bg-card/70 p-4">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className={`mt-1 font-mono text-2xl font-bold tabular-nums sm:text-3xl ${accent ?? "text-foreground"}`}>{value}</p>
    </div>
  );
}
