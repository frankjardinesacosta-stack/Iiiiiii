# Conexión con la app de iPhone

En el `Info.plist` de la app cambia `PantherAPIBaseURL` por la dirección de este panel (ej. `https://tu-panel.lovable.app`).

## POST /api/public/activate  (también /api/public/validate)
Cuerpo JSON:
```json
{
  "key": "ABCD-EFGH-JKLM-NPQR",
  "device_id": "identifierForVendor del iPhone",
  "device_model": "iPhone15,2",
  "device_name": "iPhone de Juan",
  "ios_version": "17.4.1"
}
```
También acepta: `deviceId`, `hwid`, `udid`, `model`, `machine`, `name`, `deviceName`, `systemVersion`, `os_version`.

Respuesta correcta (200):
```json
{ "ok": true, "success": true, "status": "active", "message": "Key activada.",
  "permanent": false, "expires_at": "2026-11-20T06:47:19.179Z", "expires_at_ms": 1795157239179,
  "remaining_seconds": 90061, "role": "user", "menus": [] }
```
Errores: 404 `not_found`, 403 `revoked` / `expired` / `bound_other_device`, 400 `invalid_request`.
