
create type public.app_role as enum ('admin');

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role public.app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;
create policy "Users read own roles" on public.user_roles for select to authenticated using (auth.uid() = user_id);

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.user_roles where user_id = _user_id and role = _role) $$;

-- Only one account may ever exist: block any signup once a user exists.
create or replace function public.enforce_single_account()
returns trigger language plpgsql security definer set search_path = public, auth
as $$
begin
  if exists (select 1 from auth.users) then
    raise exception 'Solo se permite una cuenta principal';
  end if;
  return new;
end;
$$;

create or replace function public.assign_owner_role()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.user_roles (user_id, role) values (new.id, 'admin') on conflict do nothing;
  return new;
end;
$$;

create trigger enforce_single_account before insert on auth.users
for each row execute function public.enforce_single_account();
create trigger assign_owner_role after insert on auth.users
for each row execute function public.assign_owner_role();

create or replace function public.owner_exists()
returns boolean language sql stable security definer set search_path = public, auth
as $$ select exists (select 1 from auth.users) $$;
grant execute on function public.owner_exists() to anon, authenticated;

create table public.license_keys (
  id uuid primary key default gen_random_uuid(),
  key text not null unique,
  note text,
  duration_seconds bigint not null default 0,
  permanent boolean not null default false,
  revoked boolean not null default false,
  created_at timestamptz not null default now(),
  activated_at timestamptz,
  expires_at timestamptz,
  device_id text,
  device_model text,
  device_name text,
  ios_version text,
  last_seen_at timestamptz
);
grant select, insert, update, delete on public.license_keys to authenticated;
grant all on public.license_keys to service_role;
alter table public.license_keys enable row level security;
create policy "Admin reads keys" on public.license_keys for select to authenticated using (public.has_role(auth.uid(), 'admin'));
create policy "Admin creates keys" on public.license_keys for insert to authenticated with check (public.has_role(auth.uid(), 'admin'));
create policy "Admin updates keys" on public.license_keys for update to authenticated using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));
create policy "Admin deletes keys" on public.license_keys for delete to authenticated using (public.has_role(auth.uid(), 'admin'));
